# rando
electron js app for desk top!

## Presentation Link

https://docs.google.com/presentation/d/15BFvESJQ2KQ33diYFA3isGlT8b7KwMkQ6GjB38UHoTA/edit?usp=sharing

![image of working app](/images/rando.png)
